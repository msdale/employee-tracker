# employee-tracker
Manage organizational employee data.  Can be used for organizational charting and department-level cost budgeting. 
